command: """
  export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
  TODAY=$(date +%Y-%m-%d)
  SINCE=$(date -v-1d +%Y%m%d 2>/dev/null || date -d yesterday +%Y%m%d)
  # One ccusage call bounded to two days (not the whole history every 30s) and
  # one jq pass that builds the JSON itself, so a null or string field can
  # never produce a malformed payload. Accepts .date or .period as the day key.
  OUT=$(ccusage daily --json --since "$SINCE" 2>/dev/null | jq -c --arg t "$TODAY" '
    ((.daily // []) | map(select((.date // .period) == $t)) | .[0]) as $d
    | if $d == null then {status:"empty", date:$t}
      else {status:"ok", date:$t,
            input:($d.inputTokens // 0), output:($d.outputTokens // 0),
            cacheRead:($d.cacheReadTokens // 0), cacheWrite:($d.cacheCreationTokens // 0),
            total:($d.totalTokens // 0), cost:($d.totalCost // 0)} end' 2>/dev/null)
  [ -n "$OUT" ] && echo "$OUT" || echo '{"status":"error","message":"ccusage not available"}'
"""

refreshFrequency: 30000

display: 'main'

render: (output) -> """
  <div class='widget-card'>
    <div class='header'>
      <div class='icon'><svg viewBox="0 0 96 96" width="26" height="26"><rect x="15" y="71" width="22" height="7" rx="3.5" fill="#CFDFE8"/><rect x="15" y="61" width="22" height="7" rx="3.5" fill="#CFDFE8"/><rect x="37" y="71" width="22" height="7" rx="3.5" fill="#CFDFE8"/><rect x="37" y="61" width="22" height="7" rx="3.5" fill="#CFDFE8"/><rect x="37" y="51" width="22" height="7" rx="3.5" fill="#CFDFE8"/><rect x="37" y="41" width="22" height="7" rx="3.5" fill="#CFDFE8"/><rect x="59" y="71" width="22" height="7" rx="3.5" fill="#CFDFE8"/><rect x="59" y="61" width="22" height="7" rx="3.5" fill="#CFDFE8"/><rect x="59" y="51" width="22" height="7" rx="3.5" fill="#CFDFE8"/><rect x="59" y="41" width="22" height="7" rx="3.5" fill="#CFDFE8"/><rect x="59" y="31" width="22" height="7" rx="3.5" fill="#CFDFE8"/><rect x="59" y="21" width="22" height="7" rx="3.5" fill="#CFDFE8"/><rect x="59" y="8" width="22" height="7" rx="3.5" fill="#F3F1EB" transform="rotate(-12 70 11.5)"/></svg></div>
      <div class='title'>Claude Code Today</div>
    </div>
    <div class='main-number' id='main'>--</div>
    <div class='subtitle' id='subtitle'>loading...</div>
    <div class='breakdown' id='breakdown'></div>
  </div>
"""

update: (output, domEl) ->
  try
    data = JSON.parse(output)
  catch e
    domEl.querySelector('#main').textContent = 'ERR'
    domEl.querySelector('#subtitle').textContent = 'parse failed'
    return

  if data.status == 'error'
    domEl.querySelector('#main').textContent = '!'
    domEl.querySelector('#subtitle').textContent = data.message
    return

  if data.status == 'empty'
    domEl.querySelector('#main').textContent = '0'
    domEl.querySelector('#subtitle').textContent = "No usage on #{data.date}"
    domEl.querySelector('#breakdown').innerHTML = ''
    return

  total = data.total
  display = if total >= 1000000 then "#{(total/1000000).toFixed(2)}M"
  else if total >= 1000 then "#{(total/1000).toFixed(1)}k"
  else "#{total}"

  fmt = (n) -> n.toLocaleString('en-US')

  domEl.querySelector('#main').textContent = display
  now = new Date()
  timeStr = now.toLocaleTimeString('en-US', {hour12: false})
  domEl.querySelector('#subtitle').innerHTML = "tokens today · #{data.date}<br><span style='opacity:0.6; font-size:11px'>updated #{timeStr}</span>"
  domEl.querySelector('#breakdown').innerHTML = """
    <div class='row'><span>Input</span><span>#{fmt(data.input)}</span></div>
    <div class='row'><span>Output</span><span>#{fmt(data.output)}</span></div>
    <div class='row'><span>Cache create</span><span>#{fmt(data.cacheWrite)}</span></div>
    <div class='row'><span>Cache read</span><span>#{fmt(data.cacheRead)}</span></div>
    <div class='row total'><span>Total</span><span>#{fmt(data.total)}</span></div>
    <div class='row cost'><span>API equiv.</span><span>$#{data.cost.toFixed(2)}</span></div>
  """

style: """
  bottom: 180px
  left: 15px
  font-family: -apple-system, 'SF Pro Display', system-ui, sans-serif
  color: #fff

  .widget-card
    background: rgba(20, 20, 24, 0.78)
    backdrop-filter: blur(24px) saturate(180%)
    -webkit-backdrop-filter: blur(24px) saturate(180%)
    border: 1px solid rgba(255, 255, 255, 0.08)
    border-radius: 18px
    padding: 18px 20px
    width: 305px
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.35)

  .header
    display: flex
    align-items: center
    gap: 8px
    margin-bottom: 10px

  .icon svg
    display: block

  .title
    font-size: 14px
    font-weight: 500
    letter-spacing: 0.3px
    text-transform: uppercase
    color: rgba(255, 255, 255, 0.6)

  .main-number
    font-size: 48px
    font-weight: 700
    letter-spacing: -1px
    line-height: 1
    color: #fff

  .subtitle
    font-size: 14px
    color: rgba(255, 255, 255, 0.5)
    margin-top: 4px
    margin-bottom: 14px

  .breakdown
    border-top: 1px solid rgba(255, 255, 255, 0.08)
    padding-top: 12px

  .row
    display: flex
    justify-content: space-between
    font-size: 12px
    padding: 3px 0
    color: rgba(255, 255, 255, 0.75)

  .row.total
    border-top: 1px solid rgba(255, 255, 255, 0.08)
    margin-top: 6px
    padding-top: 8px
    font-weight: 600
    color: #fff

  .row.cost
    color: rgba(255, 255, 255, 0.45)
    font-size: 11px
"""
